using System;

class Gato : IAnimal
{
    public void HacerSonido()
    {
        Console.WriteLine("El gato dice: Miau miau");
    }
}
