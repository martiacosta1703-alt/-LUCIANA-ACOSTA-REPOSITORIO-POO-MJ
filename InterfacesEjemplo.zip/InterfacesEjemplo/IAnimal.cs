using System;
interface IAnimal
{
    void HacerSonido();
}
