using System;

class Perro : IAnimal
{
    public void HacerSonido()
    {
        Console.WriteLine("El perro dice: Guau guau");
    }
}
