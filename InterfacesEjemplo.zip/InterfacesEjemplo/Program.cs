using System;

class Program
{
    static void Main()
    {
        IAnimal miPerro = new Perro();
        IAnimal miGato = new Gato();

        miPerro.HacerSonido();
        miGato.HacerSonido();
    }
}
